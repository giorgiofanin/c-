#include <iostream>

//int x =9;
//int a;
int main()
{
	//int x;
	//int static y = 0;
	int static z;
	return 0;
}


//compare in text,(variabili globali e statiche non inizializzate) ma non essendo inizializzata data e bbs non assumono byte
//e' automatica perche' viene allocata in automatico nello stack
//niente

